//
//  ViewController.m
//  DailyTools
//
//  Created by 乾龙 on 2018/10/23.
//  Copyright © 2018 秦乾龙. All rights reserved.
//

#import "ViewController.h"
#import "QQL_CompassViewController.h"
#import "QQL_RuleViewController.h"
#import "QQL_LevelViewController.h"
#import "QQL_NoiseViewController.h"
#import "QQL_MirrorViewController.h"
#import "QQL_CorrectViewController.h"
#import "QQL_ProtractorViewController.h"
#import "QQL_NetworkSpeedViewController.h"

@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong)UITableView *tableView;
@property (nonatomic,strong)NSArray *titileArr;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.title = @"日常工具";
    _titileArr = [NSArray arrayWithObjects:@"指南针",@"量角器",@"测噪音",@"测网速",@"水平仪",@"挂物矫正",@"尺子",@"镜子", nil];
    [self.view addSubview:self.tableView];
    self.tableView.rowHeight = 60;
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 8;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"normalCell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:(UITableViewCellStyleSubtitle) reuseIdentifier:identifier];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    cell.textLabel.text = _titileArr[indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.row == 0)
    {
        QQL_CompassViewController *VC = [[QQL_CompassViewController alloc] init];
        self.navigationController.navigationBarHidden = YES;
        [self.navigationController pushViewController:VC animated:YES];
    }
    else if (indexPath.row == 1)
    {
        QQL_ProtractorViewController *VC = [[QQL_ProtractorViewController alloc] init];
        self.navigationController.navigationBarHidden = YES;
        [self.navigationController pushViewController:VC animated:YES];
    }
    else if (indexPath.row == 2)
    {
        QQL_NoiseViewController *VC = [[QQL_NoiseViewController alloc] init];
        [self.navigationController pushViewController:VC animated:YES];
    }
    else if (indexPath.row == 3)
    {
        QQL_NetworkSpeedViewController *VC = [[QQL_NetworkSpeedViewController alloc] init];
        self.navigationController.navigationBarHidden = YES;
        [self.navigationController pushViewController:VC animated:YES];
    }
    else if (indexPath.row == 4)
    {
        QQL_LevelViewController *VC = [[QQL_LevelViewController alloc] init];
        self.navigationController.navigationBarHidden = YES;
        [self.navigationController pushViewController:VC animated:YES];
    }
    else if (indexPath.row == 5)
    {
        QQL_CorrectViewController *VC = [[QQL_CorrectViewController alloc] init];
        self.navigationController.navigationBarHidden = YES;
        [self.navigationController pushViewController:VC animated:YES];
    }
    else if (indexPath.row == 6)
    {
        QQL_RuleViewController *VC = [[QQL_RuleViewController alloc] init];
        self.navigationController.navigationBarHidden = YES;
        [self.navigationController pushViewController:VC animated:YES];
    }
    else if (indexPath.row == 7)
    {
        QQL_MirrorViewController *VC = [[QQL_MirrorViewController alloc] init];
        self.navigationController.navigationBarHidden = YES;
        [self.navigationController pushViewController:VC animated:YES];
    }
}

- (void)viewWillAppear:(BOOL)animated
{
    self.navigationController.navigationBarHidden = NO;
}
/** 懒加载 */
- (UITableView *)tableView
{
    if (!_tableView) {
        _tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
        _tableView.delegate = self;
        _tableView.dataSource = self;
    }
    return _tableView;
}
@end
