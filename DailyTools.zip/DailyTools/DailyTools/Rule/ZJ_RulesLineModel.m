//
//  ZJ_RulesLineModel.m
//  ceshi
//
//  Created by shao_Mac on 2018/5/4.
//  Copyright © 2018年 shao_Mac. All rights reserved.
//

#import "ZJ_RulesLineModel.h"

@implementation ZJ_RulesLineModel

@end
