//
//  DrawRectView.h
//  VoiceTest
//
//  Created by zhangyao on 2017/8/18.
//  Copyright © 2017年 zhangyao. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DrawRectView : UIView

@property (strong, nonatomic) CALayer *needleLayer;

- (void)show;
@end
